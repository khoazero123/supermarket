--
-- Database: `supermarket`
--
CREATE DATABASE IF NOT EXISTS `supermarket` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `supermarket`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `parent` int(2) NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `slug`, `description`, `parent`, `display`, `image`) VALUES
(1, 'Automovie & Motorcyle', 'automovie-motorcyle', NULL, 0, 1, NULL),
(2, 'Electronics', 'electronics', NULL, 0, 1, NULL),
(3, 'Fashion &amp; Accecssories', 'fashion-amp-accecssories', NULL, 0, 1, NULL),
(4, 'Smartphone &amp; Table', 'smartphone-amp-table', NULL, 0, 1, NULL),
(5, 'Furniture', 'furniture', NULL, 0, 1, NULL),
(6, 'Handbags', 'handbags', NULL, 0, 1, NULL),
(7, 'Health &amp; Beauty', 'health-amp-beauty', NULL, 0, 1, NULL),
(8, 'Bags &amp; Shoe', 'bags-amp-shoe', NULL, 0, 1, NULL),
(9, 'Accessories', 'accessories', NULL, 0, 1, NULL),
(10, 'Televisions &amp; Monitor', 'televisions-amp-monitor', NULL, 0, 1, NULL),
(11, 'Toy &amp; Hobbies', 'toy-amp-hobbies', NULL, 0, 1, NULL),
(12, 'Computer &amp; Networking', 'computer-amp-networking', NULL, 0, 1, NULL),
(13, 'Laptop &amp; Accessories', 'laptop-amp-accessories', NULL, 0, 1, NULL),
(14, 'Sport &amp; Outdoors', 'sport-amp-outdoors', NULL, 0, 1, NULL),
(15, 'Camera &amp; Lamp', 'camera-amp-lamp', NULL, 0, 1, NULL),
(16, 'Watch &amp; Shoes', 'watch-amp-shoes', NULL, 0, 1, NULL),
(17, 'SmartPhone', 'smartphone', NULL, 0, 1, NULL),
(18, 'Camera &amp; USB', 'camera-amp-usb', NULL, 0, 1, NULL),
(19, 'Electrolux &amp; Furniture', 'electrolux-amp-furniture', NULL, 0, 1, NULL),
(20, 'Sport', 'sport', NULL, 0, 1, NULL),
(21, 'Accessories', 'accessories', NULL, 2, 1, NULL),
(22, 'Swimming', 'swimming', NULL, 2, 1, NULL),
(23, 'Computers &amp; Networking', 'computers-amp-networking', NULL, 2, 1, NULL),
(24, 'Flashlights &amp; Lamps', 'flashlights-amp-lamps', NULL, 2, 1, NULL),
(25, 'Mobile', 'mobile', NULL, 21, 1, NULL),
(26, 'Tablets', 'tablets', NULL, 21, 1, NULL),
(27, 'Memory Cards', 'memory-cards', NULL, 21, 1, NULL),
(28, 'Fashion Men’s', 'fashion-men-s', NULL, 3, 1, NULL),
(29, 'Octa Core', 'octa-core', NULL, 28, 1, NULL),
(30, 'Quad Core', 'quad-core', NULL, 28, 1, NULL),
(31, 'Single SIM Card', 'single-sim-card', NULL, 28, 1, NULL),
(32, 'Dual SIM Card', 'dual-sim-card', NULL, 28, 1, NULL),
(33, '3GB RAM', '3gb-ram', NULL, 28, 1, NULL),
(34, '5.0 Display', '5-0-display', NULL, 28, 1, NULL),
(35, 'Accessories', 'accessories', NULL, 3, 1, NULL),
(36, 'Pouches', 'pouches', NULL, 35, 1, NULL),
(37, 'Bumper Cases', 'bumper-cases', NULL, 35, 1, NULL),
(38, 'Waterproof Cases', 'waterproof-cases', NULL, 35, 1, NULL),
(39, 'Leather Cases', 'leather-cases', NULL, 35, 1, NULL),
(40, 'Aluminum Cases', 'aluminum-cases', NULL, 35, 1, NULL),
(41, 'Rhinestone Cases', 'rhinestone-cases', NULL, 35, 1, NULL),
(42, 'Fashion Women’s', 'fashion-women-s', NULL, 3, 1, NULL),
(43, 'Backup Battery Packs', 'backup-battery-packs', NULL, 42, 1, NULL),
(44, 'Screen Protectors', 'screen-protectors', NULL, 42, 1, NULL),
(45, 'Mobile Phone Cables', 'mobile-phone-cables', NULL, 42, 1, NULL),
(46, 'Chargers', 'chargers', NULL, 42, 1, NULL),
(47, 'Holders &amp; Stands', 'holders-amp-stands', NULL, 42, 1, NULL),
(48, 'Mobile Phone Lenses', 'mobile-phone-lenses', NULL, 42, 1, NULL),
(49, 'Handbag &amp; Shoes', 'handbag-amp-shoes', NULL, 3, 1, NULL),
(50, 'Communications', 'communications', NULL, 49, 1, NULL),
(51, 'Communication Cables', 'communication-cables', NULL, 49, 1, NULL),
(52, 'Fiber Optic Equipment', 'fiber-optic-equipment', NULL, 49, 1, NULL),
(53, 'Fixed Wireless Terminals', 'fixed-wireless-terminals', NULL, 49, 1, NULL),
(54, 'Mobile Phones', 'mobile-phones', NULL, 4, 1, NULL),
(55, 'Octa Core', 'octa-core', NULL, 54, 1, NULL),
(56, 'Quad Core', 'quad-core', NULL, 54, 1, NULL),
(57, 'Single SIM Card', 'single-sim-card', NULL, 54, 1, NULL),
(58, 'Dual SIM Card', 'dual-sim-card', NULL, 54, 1, NULL),
(59, '3GB RAM', '3gb-ram', NULL, 54, 1, NULL),
(60, '5.0 Display', '5-0-display', NULL, 54, 1, NULL),
(61, 'Phone Bags &amp; Cases', 'phone-bags-amp-cases', NULL, 4, 1, NULL),
(62, 'Pouches', 'pouches', NULL, 61, 1, NULL),
(63, 'Bumper Cases', 'bumper-cases', NULL, 61, 1, NULL),
(64, 'Waterproof Cases', 'waterproof-cases', NULL, 61, 1, NULL),
(65, 'Leather Cases', 'leather-cases', NULL, 61, 1, NULL),
(66, 'Aluminum Cases', 'aluminum-cases', NULL, 61, 1, NULL),
(67, 'Rhinestone Cases', 'rhinestone-cases', NULL, 61, 1, NULL),
(68, 'Mobile Phone Accessories', 'mobile-phone-accessories', NULL, 4, 1, NULL),
(69, 'Backup Battery Packs', 'backup-battery-packs', NULL, 68, 1, NULL),
(70, 'Screen Protectors', 'screen-protectors', NULL, 68, 1, NULL),
(71, 'Mobile Phone Cables', 'mobile-phone-cables', NULL, 68, 1, NULL),
(72, 'Chargers', 'chargers', NULL, 68, 1, NULL),
(73, 'Holders &amp; Stands', 'holders-amp-stands', NULL, 68, 1, NULL),
(74, 'Mobile Phone Lenses', 'mobile-phone-lenses', NULL, 68, 1, NULL),
(75, 'Mobile Phone Lenses', 'mobile-phone-lenses', NULL, 4, 1, NULL),
(76, 'Mobile Phone LCDs', 'mobile-phone-lcds', NULL, 75, 1, NULL),
(77, 'Mobile Phone Batteries', 'mobile-phone-batteries', NULL, 75, 1, NULL),
(78, 'Mobile Phone Housings', 'mobile-phone-housings', NULL, 75, 1, NULL),
(79, 'Signal Boosters', 'signal-boosters', NULL, 75, 1, NULL),
(80, 'SIM Card &amp; Tools', 'sim-card-amp-tools', NULL, 75, 1, NULL),
(81, 'Walkie-Talkies', 'walkie-talkies', NULL, 4, 1, NULL),
(82, 'Walkie-Talkies', 'walkie-talkies', NULL, 81, 1, NULL),
(83, 'Walkie-Talkie Accessories', 'walkie-talkie-accessories', NULL, 81, 1, NULL),
(84, 'Communication Equipment', 'communication-equipment', NULL, 4, 1, NULL),
(85, 'Antennas for Communications', 'antennas-for-communications', NULL, 84, 1, NULL),
(86, 'Communication Cables', 'communication-cables', NULL, 84, 1, NULL),
(87, 'Fiber Optic Equipment', 'fiber-optic-equipment', NULL, 84, 1, NULL),
(88, 'Fixed Wireless Terminals', 'fixed-wireless-terminals', NULL, 84, 1, NULL),
(89, 'Handbags Formen’s', 'handbags-formen-s', NULL, 5, 1, NULL),
(90, 'Octa Core', 'octa-core', NULL, 89, 1, NULL),
(91, 'Quad Core', 'quad-core', NULL, 89, 1, NULL),
(92, 'Single SIM Card', 'single-sim-card', NULL, 89, 1, NULL),
(93, 'Dual SIM Card', 'dual-sim-card', NULL, 89, 1, NULL),
(94, '3GB RAM', '3gb-ram', NULL, 89, 1, NULL),
(95, '5.0 Display', '5-0-display', NULL, 89, 1, NULL),
(96, 'Accessories', 'accessories', NULL, 5, 1, NULL),
(97, 'Pouches', 'pouches', NULL, 96, 1, NULL),
(98, 'Bumper Cases', 'bumper-cases', NULL, 96, 1, NULL),
(99, 'Waterproof Cases', 'waterproof-cases', NULL, 96, 1, NULL),
(100, 'Leather Cases', 'leather-cases', NULL, 96, 1, NULL),
(101, 'Aluminum Cases', 'aluminum-cases', NULL, 96, 1, NULL),
(102, 'Rhinestone Cases', 'rhinestone-cases', NULL, 96, 1, NULL),
(103, 'Clothing Bags', 'clothing-bags', NULL, 5, 1, NULL),
(104, 'Mobile Phone LCDs', 'mobile-phone-lcds', NULL, 103, 1, NULL),
(105, 'Mobile Phone Batteries', 'mobile-phone-batteries', NULL, 103, 1, NULL),
(106, 'Mobile Phone Housings', 'mobile-phone-housings', NULL, 103, 1, NULL),
(107, 'Signal Boosters', 'signal-boosters', NULL, 103, 1, NULL),
(108, 'Walkie-Talkies', 'walkie-talkies', NULL, 5, 1, NULL),
(109, 'Walkie-Talkies', 'walkie-talkies', NULL, 108, 1, NULL),
(110, 'Walkie-Talkie Accessories', 'walkie-talkie-accessories', NULL, 108, 1, NULL),
(111, 'Industrial Supplies', 'industrial-supplies', NULL, 6, 1, NULL),
(112, 'All Industrial Supplies', 'all-industrial-supplies', NULL, 111, 1, NULL),
(113, 'Lab &amp; Scientific', 'lab-amp-scientific', NULL, 111, 1, NULL),
(114, 'Janitorial', 'janitorial', NULL, 111, 1, NULL),
(115, 'Sanitation Supplies', 'sanitation-supplies', NULL, 111, 1, NULL),
(116, '3GB RAM', '3gb-ram', NULL, 111, 1, NULL),
(117, '5.0 Display', '5-0-display', NULL, 111, 1, NULL),
(118, 'Car &amp; MotorbikeNew', 'car-amp-motorbikenew', NULL, 6, 1, NULL),
(119, 'All Cars &amp; Bikes', 'all-cars-amp-bikes', NULL, 118, 1, NULL),
(120, 'Measure &amp; Inspect', 'measure-amp-inspect', NULL, 118, 1, NULL),
(121, 'Car &amp; Bike Care', 'car-amp-bike-care', NULL, 118, 1, NULL),
(122, 'Lubricants', 'lubricants', NULL, 118, 1, NULL),
(123, 'Shop for Bike', 'shop-for-bike', NULL, 6, 1, NULL),
(124, 'Backup Battery Packs', 'backup-battery-packs', NULL, 123, 1, NULL),
(125, 'Helmets &amp; Gloves', 'helmets-amp-gloves', NULL, 123, 1, NULL),
(126, 'Screen Protectors', 'screen-protectors', NULL, 123, 1, NULL),
(127, 'Bike Parts', 'bike-parts', NULL, 123, 1, NULL),
(128, 'Scarves', 'scarves', NULL, 123, 1, NULL),
(129, 'Skirts', 'skirts', NULL, 123, 1, NULL),
(130, 'Shop for Car', 'shop-for-car', NULL, 6, 1, NULL),
(131, 'Air Fresheners', 'air-fresheners', NULL, 130, 1, NULL),
(132, 'Car Parts', 'car-parts', NULL, 130, 1, NULL),
(133, 'Tyre Accessories', 'tyre-accessories', NULL, 130, 1, NULL),
(134, 'SIM Card &amp; Tools', 'sim-card-amp-tools', NULL, 130, 1, NULL),
(135, 'Signal Boosters', 'signal-boosters', NULL, 130, 1, NULL),
(136, 'Football', 'football', NULL, 6, 1, NULL),
(137, 'Coats &amp; Jackets', 'coats-amp-jackets', NULL, 136, 1, NULL),
(138, 'Blouses &amp; Shirts', 'blouses-amp-shirts', NULL, 136, 1, NULL),
(139, 'Tops &amp; Tees', 'tops-amp-tees', NULL, 136, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

DROP TABLE IF EXISTS `resetpassword`;
CREATE TABLE `resetpassword` (
  `id` int(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `token` varchar(250) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resetpassword`
--

INSERT INTO `resetpassword` (`id`, `email`, `token`, `datetime`, `status`) VALUES
(1, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:24:48', 0),
(2, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:10', 0),
(3, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:39', 0),
(4, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:50', 0),
(5, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:26:44', 0),
(6, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:27:11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(9) NOT NULL,
  `firstname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `middlename` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `displayname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `token_reset_pass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `middlename`, `lastname`, `displayname`, `email`, `phone`, `address`, `city`, `state`, `postcode`, `country`, `gender`, `password`, `company`, `admin`, `token_reset_pass`, `created`) VALUES
(1, 'Khoa', 'Vo', 'Van', NULL, 'khoazero123@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 1, '81dc9bdb52d04dc20036dbd8313ed055', NULL, 0, NULL, '2017-05-24 23:48:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resetpassword`
--
ALTER TABLE `resetpassword`
  ADD KEY `id` (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;
--
-- AUTO_INCREMENT for table `resetpassword`
--
ALTER TABLE `resetpassword`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
