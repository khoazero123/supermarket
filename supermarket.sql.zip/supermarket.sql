--
-- Database: `supermarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `parent` int(2) NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent`, `display`) VALUES
(1, 'Automovie & Motorcyle', NULL, 0, 1),
(2, 'Electronics', NULL, 0, 1),
(3, 'Fashion &amp; Accecssories', NULL, 0, 1),
(4, 'Smartphone &amp; Table', NULL, 0, 1),
(5, 'Furniture', NULL, 0, 1),
(6, 'Handbags', NULL, 0, 1),
(7, 'Health &amp; Beauty', NULL, 0, 1),
(8, 'Bags &amp; Shoe', NULL, 0, 1),
(9, 'Accessories', NULL, 0, 1),
(10, 'Televisions &amp; Monitor', NULL, 0, 1),
(11, 'Toy &amp; Hobbies', NULL, 0, 1),
(12, 'Computer &amp; Networking', NULL, 0, 1),
(13, 'Laptop &amp; Accessories', NULL, 0, 1),
(14, 'Sport &amp; Outdoors', NULL, 0, 1),
(15, 'Camera &amp; Lamp', NULL, 0, 1),
(16, 'Watch &amp; Shoes', NULL, 0, 1),
(17, 'SmartPhone', NULL, 0, 1),
(18, 'Camera &amp; USB', NULL, 0, 1),
(19, 'Electrolux &amp; Furniture', NULL, 0, 1),
(20, 'Sport', NULL, 0, 1),
(21, 'Accessories', NULL, 2, 1),
(22, 'Swimming', NULL, 2, 1),
(23, 'Computers &amp; Networking', NULL, 2, 1),
(24, 'Flashlights &amp; Lamps', NULL, 2, 1),
(25, 'Mobile', NULL, 21, 1),
(26, 'Tablets', NULL, 21, 1),
(27, 'Memory Cards', NULL, 21, 1),
(28, 'Fashion Men’s', NULL, 3, 1),
(29, 'Octa Core', NULL, 28, 1),
(30, 'Quad Core', NULL, 28, 1),
(31, 'Single SIM Card', NULL, 28, 1),
(32, 'Dual SIM Card', NULL, 28, 1),
(33, '3GB RAM', NULL, 28, 1),
(34, '5.0 Display', NULL, 28, 1),
(35, 'Accessories', NULL, 3, 1),
(36, 'Pouches', NULL, 35, 1),
(37, 'Bumper Cases', NULL, 35, 1),
(38, 'Waterproof Cases', NULL, 35, 1),
(39, 'Leather Cases', NULL, 35, 1),
(40, 'Aluminum Cases', NULL, 35, 1),
(41, 'Rhinestone Cases', NULL, 35, 1),
(42, 'Fashion Women’s', NULL, 3, 1),
(43, 'Backup Battery Packs', NULL, 42, 1),
(44, 'Screen Protectors', NULL, 42, 1),
(45, 'Mobile Phone Cables', NULL, 42, 1),
(46, 'Chargers', NULL, 42, 1),
(47, 'Holders &amp; Stands', NULL, 42, 1),
(48, 'Mobile Phone Lenses', NULL, 42, 1),
(49, 'Handbag &amp; Shoes', NULL, 3, 1),
(50, 'Communications', NULL, 49, 1),
(51, 'Communication Cables', NULL, 49, 1),
(52, 'Fiber Optic Equipment', NULL, 49, 1),
(53, 'Fixed Wireless Terminals', NULL, 49, 1),
(54, 'Mobile Phones', NULL, 4, 1),
(55, 'Octa Core', NULL, 54, 1),
(56, 'Quad Core', NULL, 54, 1),
(57, 'Single SIM Card', NULL, 54, 1),
(58, 'Dual SIM Card', NULL, 54, 1),
(59, '3GB RAM', NULL, 54, 1),
(60, '5.0 Display', NULL, 54, 1),
(61, 'Phone Bags &amp; Cases', NULL, 4, 1),
(62, 'Pouches', NULL, 61, 1),
(63, 'Bumper Cases', NULL, 61, 1),
(64, 'Waterproof Cases', NULL, 61, 1),
(65, 'Leather Cases', NULL, 61, 1),
(66, 'Aluminum Cases', NULL, 61, 1),
(67, 'Rhinestone Cases', NULL, 61, 1),
(68, 'Mobile Phone Accessories', NULL, 4, 1),
(69, 'Backup Battery Packs', NULL, 68, 1),
(70, 'Screen Protectors', NULL, 68, 1),
(71, 'Mobile Phone Cables', NULL, 68, 1),
(72, 'Chargers', NULL, 68, 1),
(73, 'Holders &amp; Stands', NULL, 68, 1),
(74, 'Mobile Phone Lenses', NULL, 68, 1),
(75, 'Mobile Phone Lenses', NULL, 4, 1),
(76, 'Mobile Phone LCDs', NULL, 75, 1),
(77, 'Mobile Phone Batteries', NULL, 75, 1),
(78, 'Mobile Phone Housings', NULL, 75, 1),
(79, 'Signal Boosters', NULL, 75, 1),
(80, 'SIM Card &amp; Tools', NULL, 75, 1),
(81, 'Walkie-Talkies', NULL, 4, 1),
(82, 'Walkie-Talkies', NULL, 81, 1),
(83, 'Walkie-Talkie Accessories', NULL, 81, 1),
(84, 'Communication Equipment', NULL, 4, 1),
(85, 'Antennas for Communications', NULL, 84, 1),
(86, 'Communication Cables', NULL, 84, 1),
(87, 'Fiber Optic Equipment', NULL, 84, 1),
(88, 'Fixed Wireless Terminals', NULL, 84, 1),
(89, 'Handbags Formen’s', NULL, 5, 1),
(90, 'Octa Core', NULL, 89, 1),
(91, 'Quad Core', NULL, 89, 1),
(92, 'Single SIM Card', NULL, 89, 1),
(93, 'Dual SIM Card', NULL, 89, 1),
(94, '3GB RAM', NULL, 89, 1),
(95, '5.0 Display', NULL, 89, 1),
(96, 'Accessories', NULL, 5, 1),
(97, 'Pouches', NULL, 96, 1),
(98, 'Bumper Cases', NULL, 96, 1),
(99, 'Waterproof Cases', NULL, 96, 1),
(100, 'Leather Cases', NULL, 96, 1),
(101, 'Aluminum Cases', NULL, 96, 1),
(102, 'Rhinestone Cases', NULL, 96, 1),
(103, 'Clothing Bags', NULL, 5, 1),
(104, 'Mobile Phone LCDs', NULL, 103, 1),
(105, 'Mobile Phone Batteries', NULL, 103, 1),
(106, 'Mobile Phone Housings', NULL, 103, 1),
(107, 'Signal Boosters', NULL, 103, 1),
(108, 'Walkie-Talkies', NULL, 5, 1),
(109, 'Walkie-Talkies', NULL, 108, 1),
(110, 'Walkie-Talkie Accessories', NULL, 108, 1),
(111, 'Industrial Supplies', NULL, 6, 1),
(112, 'All Industrial Supplies', NULL, 111, 1),
(113, 'Lab &amp; Scientific', NULL, 111, 1),
(114, 'Janitorial', NULL, 111, 1),
(115, 'Sanitation Supplies', NULL, 111, 1),
(116, '3GB RAM', NULL, 111, 1),
(117, '5.0 Display', NULL, 111, 1),
(118, 'Car &amp; MotorbikeNew', NULL, 6, 1),
(119, 'All Cars &amp; Bikes', NULL, 118, 1),
(120, 'Measure &amp; Inspect', NULL, 118, 1),
(121, 'Car &amp; Bike Care', NULL, 118, 1),
(122, 'Lubricants', NULL, 118, 1),
(123, 'Shop for Bike', NULL, 6, 1),
(124, 'Backup Battery Packs', NULL, 123, 1),
(125, 'Helmets &amp; Gloves', NULL, 123, 1),
(126, 'Screen Protectors', NULL, 123, 1),
(127, 'Bike Parts', NULL, 123, 1),
(128, 'Scarves', NULL, 123, 1),
(129, 'Skirts', NULL, 123, 1),
(130, 'Shop for Car', NULL, 6, 1),
(131, 'Air Fresheners', NULL, 130, 1),
(132, 'Car Parts', NULL, 130, 1),
(133, 'Tyre Accessories', NULL, 130, 1),
(134, 'SIM Card &amp; Tools', NULL, 130, 1),
(135, 'Signal Boosters', NULL, 130, 1),
(136, 'Football', NULL, 6, 1),
(137, 'Coats &amp; Jackets', NULL, 136, 1),
(138, 'Blouses &amp; Shirts', NULL, 136, 1),
(139, 'Tops &amp; Tees', NULL, 136, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category2`
--

DROP TABLE IF EXISTS `category2`;
CREATE TABLE `category2` (
  `id` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `parent_id` int(2) NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category2`
--

INSERT INTO `category2` (`id`, `name`, `slug`, `parent_id`, `display`) VALUES
(1, 'Automovie & Motorcyle', NULL, 0, 1),
(2, 'Electronics', NULL, 0, 1),
(3, 'Fashion & Accecssories', NULL, 0, 1),
(4, 'Smartphone & Table', NULL, 0, 1),
(5, 'Furniture', NULL, 0, 1),
(6, 'Handbags', NULL, 0, 1),
(7, 'Health & Beauty', NULL, 0, 1),
(8, 'Bags & Shoe', NULL, 0, 1),
(9, 'Accessories', NULL, 0, 1),
(10, 'Televisions & Monitor', NULL, 0, 1),
(11, 'Toy & Hobbies', NULL, 0, 1),
(12, 'Computer & Networking', NULL, 0, 1),
(13, 'Laptop & Accessories', NULL, 0, 1),
(14, 'Sport & Outdoors', NULL, 0, 1),
(15, 'Camera & Lamp', NULL, 0, 1),
(16, 'Watch & Shoes', NULL, 0, 1),
(17, 'SmartPhone', NULL, 0, 1),
(18, 'Camera & USB', NULL, 0, 1),
(19, 'Electrolux & Furniture', NULL, 0, 1),
(20, 'Sport', NULL, 0, 1),
(21, 'Accessories', NULL, 2, 1),
(22, 'Swimming', NULL, 2, 1),
(23, 'Computers & Networking', NULL, 2, 1),
(24, 'Flashlights & Lamps', NULL, 2, 1),
(25, 'Fashion Men''s', NULL, 3, 1),
(26, 'Accessories', NULL, 3, 1),
(27, 'Fashion Women''s', NULL, 3, 1),
(28, 'Handbag & Shoes', NULL, 3, 1),
(29, 'Smartphone & Table', NULL, 4, 1),
(30, 'Mobile Phones', NULL, 4, 1),
(31, 'Phone Bags & Cases', NULL, 4, 1),
(32, 'Mobile Phone Accessories', NULL, 4, 1),
(33, 'Mobile Phone Parts', NULL, 4, 1),
(34, 'Walkie-Talkies', NULL, 4, 1),
(35, 'Communication Equipment', NULL, 4, 1),
(36, 'Furniture', NULL, 5, 1),
(37, 'Handbags Formen''s', NULL, 5, 1),
(38, 'Accessories', NULL, 5, 1),
(39, 'Clothing Bags', NULL, 5, 1),
(40, 'Walkie-Talkies', NULL, 5, 1),
(41, 'Handbags', NULL, 6, 1),
(42, 'Industrial Supplies', NULL, 6, 1),
(43, 'Car & Motorbike', NULL, 6, 1),
(44, 'Shop For Bike', NULL, 6, 1),
(45, 'Shop For Car', NULL, 6, 1),
(46, 'Football', NULL, 6, 1),
(47, 'Mobile', NULL, 21, 1),
(48, 'Tablets', NULL, 21, 1),
(49, 'Memory Cards', NULL, 21, 1);

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

DROP TABLE IF EXISTS `resetpassword`;
CREATE TABLE `resetpassword` (
  `id` int(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `token` varchar(250) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resetpassword`
--

INSERT INTO `resetpassword` (`id`, `email`, `token`, `datetime`, `status`) VALUES
(1, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:24:48', 0),
(2, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:10', 0),
(3, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:39', 0),
(4, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:25:50', 0),
(5, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:26:44', 0),
(6, 'khoazero123@gmail.com', '78bbf90e1091724347e312c2e4c049df', '2017-05-25 08:27:11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(9) NOT NULL,
  `firstname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `middlename` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `displayname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `token_reset_pass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `middlename`, `lastname`, `displayname`, `email`, `phone`, `address`, `city`, `state`, `postcode`, `country`, `gender`, `password`, `company`, `admin`, `token_reset_pass`, `created`) VALUES
(1, 'Khoa', 'Vo', 'Van', NULL, 'khoazero123@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 1, '81dc9bdb52d04dc20036dbd8313ed055', NULL, 0, NULL, '2017-05-24 23:48:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category2`
--
ALTER TABLE `category2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resetpassword`
--
ALTER TABLE `resetpassword`
  ADD KEY `id` (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;
--
-- AUTO_INCREMENT for table `category2`
--
ALTER TABLE `category2`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `resetpassword`
--
ALTER TABLE `resetpassword`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
